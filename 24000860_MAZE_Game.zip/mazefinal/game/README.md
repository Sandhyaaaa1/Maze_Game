# 🧩 MazeGame - Console-Based Maze Adventure

A simple and fun 2D maze game built with C++. Navigate through randomly generated mazes, collect items, dodge enemies, and reach the exit—all within a limited number of moves.

---

## 🎮 Features

- Randomly generated 10x10 maze for each level
- Collectibles that increase your score
- Enemies that move randomly—touching them ends the game
- Exit point to complete the level and move to the next
- Level progression with increasing difficulty (more enemies)
- Moves are limited per level (30 max)
- Clean ASCII-art based maze visualization in the console

---

## 🧱 Game Symbols

| Symbol | Meaning         |
|--------|-----------------|
| `P`    | Player           |
| `█`    | Wall             |
| ` `    | Path (walkable)  |
| `*`    | Collectible      |
| `X`    | Enemy (danger!)  |
| `E`    | Exit             |

---

## 🎮 Controls

- `W` - Move Up  
- `A` - Move Left  
- `S` - Move Down  
- `D` - Move Right  
- `Q` - Quit Game  

---

## 🖥️ How to Run

### 🪟 On Windows

1. Make sure you have a C++ compiler like `g++` installed.
2. Save the code in a file named `MazeGame.cpp`.
3. Compile the code using:

   ```bash
   g++ -o MazeGame MazeGame.cpp
# 🧩 MazeGame - Console-Based Maze Adventure

A simple and fun 2D maze game built with C++. Navigate through randomly generated mazes, collect items, dodge enemies, and reach the exit—all within a limited number of moves.

---

## 🎮 Features

- Randomly generated 10x10 maze for each level
- Collectibles that increase your score
- Enemies that move randomly—touching them ends the game
- Exit point to complete the level and move to the next
- Level progression with increasing difficulty (more enemies)
- Moves are limited per level (30 max)
- Clean ASCII-art based maze visualization in the console

---

## 🧱 Game Symbols

| Symbol | Meaning         |
|--------|-----------------|
| `P`    | Player           |
| `█`    | Wall             |
| ` `    | Path (walkable)  |
| `*`    | Collectible      |
| `X`    | Enemy (danger!)  |
| `E`    | Exit             |

---

## 🎮 Controls

- `W` - Move Up  
- `A` - Move Left  
- `S` - Move Down  
- `D` - Move Right  
- `Q` - Quit Game  

---

## 🖥️ How to Run

### 🪟 On Windows

1. Make sure you have a C++ compiler like `g++` installed.
2. Save the code in a file named `MazeGame.cpp`.
3. Compile the code using:

   ```bash
   g++ -o MazeGame MazeGame.cpp
MazeGame

 Platform Note
This game uses _getch() from <conio.h>, which is Windows-only.
To run it on Linux/Mac, replace _getch() with getchar() or use a cross-platform input library like ncurses.

🚀 Possible Enhancements
Smarter enemy AI using pathfinding (e.g., A*)

Health or shield system

Maze difficulty options

Save/load progress

Graphical version using SFML

📸 Preview
pgsql
Copy
Edit
+----------+
|P   █     |
|█ █ █ ███ |
|  *   █ * |
|█ █ █   █ |
|█ ███ ███ |
|█     X   |
|███ ███ █ |
|   * █ █E |
|█ █ █ ███ |
|   █      |
+----------+
Score: 1 | Level: 2 | Moves Left: 15
Controls: W/A/S/D to move, Q to quit
📄 License
This project is free to use and modify. Attribution is appreciated but not required.

Enjoy the game and feel free to expand it! 🎉