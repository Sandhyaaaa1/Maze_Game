#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <conio.h>  // For _getch on Windows
using namespace std;

// Game Symbols
const char WALL = 219;
const char PATH = ' ';
const char PLAYER = 'P';
const char EXIT = 'E';
const char COLLECTIBLE = '*';
const char ENEMY = 'X';

const int MAZE_SIZE = 10;
const int MAX_MOVES = 30;

class MazeGame {
private:
    char maze[MAZE_SIZE][MAZE_SIZE];
    int playerX, playerY;
    int exitX, exitY;
    int score = 0;
    int level = 1;
    int moves = 0;
    vector<pair<int, int>> enemies;

public:
    MazeGame() {
        srand(static_cast<unsigned int>(time(0)));
        generateMaze();
    }

    void clearScreen() {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
    }

    void generateMaze() {
        // Generate base maze
        for (int i = 0; i < MAZE_SIZE; ++i) {
            for (int j = 0; j < MAZE_SIZE; ++j) {
                if (i == 0 || j == 0 || i == MAZE_SIZE - 1 || j == MAZE_SIZE - 1 || rand() % 6 == 0)
                    maze[i][j] = WALL;
                else
                    maze[i][j] = PATH;
            }
        }

        // Player start
        playerX = 1;
        playerY = 1;
        maze[playerX][playerY] = PLAYER;

        // Exit
        exitX = MAZE_SIZE - 2;
        exitY = MAZE_SIZE - 2;
        maze[exitX][exitY] = EXIT;

        // Place collectibles
        for (int i = 0; i < 3; ++i) {
            int x, y;
            do {
                x = rand() % MAZE_SIZE;
                y = rand() % MAZE_SIZE;
            } while (maze[x][y] != PATH);
            maze[x][y] = COLLECTIBLE;
        }

        // Place enemies
        enemies.clear();
        for (int i = 0; i < level; ++i) {
            int x, y;
            do {
                x = rand() % MAZE_SIZE;
                y = rand() % MAZE_SIZE;
            } while (maze[x][y] != PATH);
            maze[x][y] = ENEMY;
            enemies.push_back({x, y});
        }
    }

    void drawMaze() {
        clearScreen();
        cout << "+";
        for (int i = 0; i < MAZE_SIZE; ++i) cout << "-";
        cout << "+" << endl;

        for (int i = 0; i < MAZE_SIZE; ++i) {
            cout << "|";
            for (int j = 0; j < MAZE_SIZE; ++j) {
                cout << maze[i][j];
            }
            cout << "|" << endl;
        }

        cout << "+";
        for (int i = 0; i < MAZE_SIZE; ++i) cout << "-";
        cout << "+" << endl;

        cout << "Score: " << score << " | Level: " << level << " | Moves Left: " << (MAX_MOVES - moves) << endl;
        cout << "Controls: W/A/S/D to move, Q to quit" << endl;
    }

    void movePlayer(char input) {
        int dx = 0, dy = 0;
        if (input == 'w' || input == 'W') dx = -1;
        else if (input == 's' || input == 'S') dx = 1;
        else if (input == 'a' || input == 'A') dy = -1;
        else if (input == 'd' || input == 'D') dy = 1;
        else return;

        int newX = playerX + dx;
        int newY = playerY + dy;

        if (maze[newX][newY] == WALL) return; // hit wall

        if (maze[newX][newY] == COLLECTIBLE) score++;
        else if (maze[newX][newY] == ENEMY) {
            cout << "\nGAME OVER: You were caught by an enemy!" << endl;
            exit(0);
        } else if (maze[newX][newY] == EXIT) {
            level++;
            moves = 0;
            generateMaze();
            return;
        }

        maze[playerX][playerY] = PATH;
        playerX = newX;
        playerY = newY;
        maze[playerX][playerY] = PLAYER;
        moves++;

        if (moves >= MAX_MOVES) {
            cout << "\nGAME OVER: You ran out of moves!" << endl;
            exit(0);
        }
    }

    void moveEnemies() {
        for (auto& enemy : enemies) {
            int ex = enemy.first;
            int ey = enemy.second;
            int dir = rand() % 4;
            int dx = 0, dy = 0;

            if (dir == 0) dx = -1;
            else if (dir == 1) dx = 1;
            else if (dir == 2) dy = -1;
            else dy = 1;

            int nx = ex + dx;
            int ny = ey + dy;

            if (maze[nx][ny] == PATH || maze[nx][ny] == PLAYER) {
                if (maze[nx][ny] == PLAYER) {
                    cout << "\nGAME OVER: You were caught by an enemy!" << endl;
                    exit(0);
                }

                maze[ex][ey] = PATH;
                maze[nx][ny] = ENEMY;
                enemy = {nx, ny};
            }
        }
    }

    void play() {
        while (true) {
            drawMaze();
            char input = _getch();  // For Windows. On Linux, use getchar().
            if (input == 'q' || input == 'Q') {
                cout << "Exiting game. Thanks for playing!" << endl;
                break;
            }
            movePlayer(input);
            moveEnemies();
        }
    }
};

int main() {
    MazeGame game;
    game.play();
    return 0;
}
